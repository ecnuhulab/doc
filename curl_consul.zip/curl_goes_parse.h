
#ifndef cGOES__h
#define cGOES__h

#ifdef __cplusplus
extern "C"
{
#endif

#if !defined(__WINDOWS__) && (defined(WIN32) || defined(WIN64) || defined(_MSC_VER) || defined(_WIN32))
#define __WINDOWS__
#endif

#ifdef __WINDOWS__


#define CGOES_CDECL __cdecl
#define CGOES_STDCALL __stdcall

/* export symbols by default, this is necessary for copy pasting the C and header file */
#if !defined(CGOES_HIDE_SYMBOLS) && !defined(CGOES_IMPORT_SYMBOLS) && !defined(CGOES_EXPORT_SYMBOLS)
#define CGOES_EXPORT_SYMBOLS
#endif

#if defined(CGOES_HIDE_SYMBOLS)
#define CGOES_PUBLIC(type)   type CGOES_STDCALL
#elif defined(CGOES_EXPORT_SYMBOLS)
#define CGOES_PUBLIC(type)   __declspec(dllexport) type CGOES_STDCALL
#elif defined(CGOES_IMPORT_SYMBOLS)
#define CGOES_PUBLIC(type)   __declspec(dllimport) type CGOES_STDCALL
#endif
#else /* !__WINDOWS__ */
#define CGOES_CDECL
#define CGOES_STDCALL

#if (defined(__GNUC__) || defined(__SUNPRO_CC) || defined (__SUNPRO_C)) && defined(CGOES_API_VISIBILITY)
#define CGOES_PUBLIC(type)   __attribute__((visibility("default"))) type
#else
#define CGOES_PUBLIC(type) type
#endif
#endif

/* project version */
#define CGOES_VERSION_MAJOR 1
#define CGOES_VERSION_MINOR 7
#define CGOES_VERSION_PATCH 12

#include <stddef.h>

/* cGOES Types: */
#define cGOES_Invalid (0)
#define cGOES_False  (1 << 0)
#define cGOES_True   (1 << 1)
#define cGOES_NULL   (1 << 2)
#define cGOES_Number (1 << 3)
#define cGOES_String (1 << 4)
#define cGOES_Array  (1 << 5)
#define cGOES_Object (1 << 6)
#define cGOES_Raw    (1 << 7) /* raw json */

#define cGOES_IsReference 256
#define cGOES_StringIsConst 512

/* The cGOES structure: */
typedef struct cGOES
{
    struct cGOES *next;
    struct cGOES *prev;
    struct cGOES *child;

    int type;

    char *valuestring;
    int valueint;
    double valuedouble;

    char *string;
} cGOES;

typedef struct cGOES_Hooks
{
      /* malloc/free are CDECL on Windows regardless of the default calling convention of the compiler, so ensure the hooks allow passing those functions directly. */
      void *(CGOES_CDECL *malloc_fn)(size_t sz);
      void (CGOES_CDECL *free_fn)(void *ptr);
} cGOES_Hooks;

typedef int cGOES_bool;

/* Limits how deeply nested arrays/objects can be before cGOES rejects to parse them.
 * This is to prevent stack overflows. */
#ifndef CGOES_NESTING_LIMIT
#define CGOES_NESTING_LIMIT 1000
#endif

CGOES_PUBLIC(const char*) cGOES_Version(void);

CGOES_PUBLIC(void) cGOES_InitHooks(cGOES_Hooks* hooks);

CGOES_PUBLIC(cGOES *) cGOES_Parse(const char *value);
CGOES_PUBLIC(cGOES *) cGOES_ParseWithOpts(const char *value, const char **return_parse_end, cGOES_bool require_null_terminated);

CGOES_PUBLIC(char *) cGOES_Print(const cGOES *item);
CGOES_PUBLIC(char *) cGOES_PrintUnformatted(const cGOES *item);
CGOES_PUBLIC(char *) cGOES_PrintBuffered(const cGOES *item, int prebuffer, cGOES_bool fmt);
CGOES_PUBLIC(cGOES_bool) cGOES_PrintPreallocated(cGOES *item, char *buffer, const int length, const cGOES_bool format);
CGOES_PUBLIC(void) cGOES_Delete(cGOES *c);

CGOES_PUBLIC(int) cGOES_GetArraySize(const cGOES *array);
CGOES_PUBLIC(cGOES *) cGOES_GetArrayItem(const cGOES *array, int index);
CGOES_PUBLIC(cGOES *) cGOES_GetObjectItem(const cGOES * const object, const char * const string);
CGOES_PUBLIC(cGOES *) cGOES_GetObjectItemCaseSensitive(const cGOES * const object, const char * const string);
CGOES_PUBLIC(cGOES_bool) cGOES_HasObjectItem(const cGOES *object, const char *string);
CGOES_PUBLIC(const char *) cGOES_GetErrorPtr(void);

CGOES_PUBLIC(char *) cGOES_GetStringValue(cGOES *item);

CGOES_PUBLIC(cGOES_bool) cGOES_IsInvalid(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsFalse(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsTrue(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsBool(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsNull(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsNumber(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsString(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsArray(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsObject(const cGOES * const item);
CGOES_PUBLIC(cGOES_bool) cGOES_IsRaw(const cGOES * const item);

CGOES_PUBLIC(cGOES *) cGOES_CreateNull(void);
CGOES_PUBLIC(cGOES *) cGOES_CreateTrue(void);
CGOES_PUBLIC(cGOES *) cGOES_CreateFalse(void);
CGOES_PUBLIC(cGOES *) cGOES_CreateBool(cGOES_bool boolean);
CGOES_PUBLIC(cGOES *) cGOES_CreateNumber(double num);
CGOES_PUBLIC(cGOES *) cGOES_CreateString(const char *string);
CGOES_PUBLIC(cGOES *) cGOES_CreateRaw(const char *raw);
CGOES_PUBLIC(cGOES *) cGOES_CreateArray(void);
CGOES_PUBLIC(cGOES *) cGOES_CreateObject(void);

CGOES_PUBLIC(cGOES *) cGOES_CreateStringReference(const char *string);
CGOES_PUBLIC(cGOES *) cGOES_CreateObjectReference(const cGOES *child);
CGOES_PUBLIC(cGOES *) cGOES_CreateArrayReference(const cGOES *child);

CGOES_PUBLIC(cGOES *) cGOES_CreateIntArray(const int *numbers, int count);
CGOES_PUBLIC(cGOES *) cGOES_CreateFloatArray(const float *numbers, int count);
CGOES_PUBLIC(cGOES *) cGOES_CreateDoubleArray(const double *numbers, int count);
CGOES_PUBLIC(cGOES *) cGOES_CreateStringArray(const char **strings, int count);

/* Append item to the specified array/object. */
CGOES_PUBLIC(void) cGOES_AddItemToArray(cGOES *array, cGOES *item);
CGOES_PUBLIC(void) cGOES_AddItemToObject(cGOES *object, const char *string, cGOES *item);
CGOES_PUBLIC(void) cGOES_AddItemToObjectCS(cGOES *object, const char *string, cGOES *item);
CGOES_PUBLIC(void) cGOES_AddItemReferenceToArray(cGOES *array, cGOES *item);
CGOES_PUBLIC(void) cGOES_AddItemReferenceToObject(cGOES *object, const char *string, cGOES *item);

CGOES_PUBLIC(cGOES *) cGOES_DetachItemViaPointer(cGOES *parent, cGOES * const item);
CGOES_PUBLIC(cGOES *) cGOES_DetachItemFromArray(cGOES *array, int which);
CGOES_PUBLIC(void) cGOES_DeleteItemFromArray(cGOES *array, int which);
CGOES_PUBLIC(cGOES *) cGOES_DetachItemFromObject(cGOES *object, const char *string);
CGOES_PUBLIC(cGOES *) cGOES_DetachItemFromObjectCaseSensitive(cGOES *object, const char *string);
CGOES_PUBLIC(void) cGOES_DeleteItemFromObject(cGOES *object, const char *string);
CGOES_PUBLIC(void) cGOES_DeleteItemFromObjectCaseSensitive(cGOES *object, const char *string);

CGOES_PUBLIC(void) cGOES_InsertItemInArray(cGOES *array, int which, cGOES *newitem); /* Shifts pre-existing items to the right. */
CGOES_PUBLIC(cGOES_bool) cGOES_ReplaceItemViaPointer(cGOES * const parent, cGOES * const item, cGOES * replacement);
CGOES_PUBLIC(void) cGOES_ReplaceItemInArray(cGOES *array, int which, cGOES *newitem);
CGOES_PUBLIC(void) cGOES_ReplaceItemInObject(cGOES *object,const char *string,cGOES *newitem);
CGOES_PUBLIC(void) cGOES_ReplaceItemInObjectCaseSensitive(cGOES *object,const char *string,cGOES *newitem);

CGOES_PUBLIC(cGOES *) cGOES_Duplicate(const cGOES *item, cGOES_bool recurse);
CGOES_PUBLIC(cGOES_bool) cGOES_Compare(const cGOES * const a, const cGOES * const b, const cGOES_bool case_sensitive);


CGOES_PUBLIC(void) cGOES_Minify(char *json);

CGOES_PUBLIC(cGOES*) cGOES_AddNullToObject(cGOES * const object, const char * const name);
CGOES_PUBLIC(cGOES*) cGOES_AddTrueToObject(cGOES * const object, const char * const name);
CGOES_PUBLIC(cGOES*) cGOES_AddFalseToObject(cGOES * const object, const char * const name);
CGOES_PUBLIC(cGOES*) cGOES_AddBoolToObject(cGOES * const object, const char * const name, const cGOES_bool boolean);
CGOES_PUBLIC(cGOES*) cGOES_AddNumberToObject(cGOES * const object, const char * const name, const double number);
CGOES_PUBLIC(cGOES*) cGOES_AddStringToObject(cGOES * const object, const char * const name, const char * const string);
CGOES_PUBLIC(cGOES*) cGOES_AddRawToObject(cGOES * const object, const char * const name, const char * const raw);
CGOES_PUBLIC(cGOES*) cGOES_AddObjectToObject(cGOES * const object, const char * const name);
CGOES_PUBLIC(cGOES*) cGOES_AddArrayToObject(cGOES * const object, const char * const name);

#define cGOES_SetIntValue(object, number) ((object) ? (object)->valueint = (object)->valuedouble = (number) : (number))
CGOES_PUBLIC(double) cGOES_SetNumberHelper(cGOES *object, double number);
#define cGOES_SetNumberValue(object, number) ((object != NULL) ? cGOES_SetNumberHelper(object, (double)number) : (number))

#define cGOES_ArrayForEach(element, array) for(element = (array != NULL) ? (array)->child : NULL; element != NULL; element = element->next)

CGOES_PUBLIC(void *) cGOES_malloc(size_t size);
CGOES_PUBLIC(void) cGOES_free(void *object);

#ifdef __cplusplus
}
#endif

#endif
