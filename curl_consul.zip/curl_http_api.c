#include <string.h>
#include <errno.h>
#include "curl_http_def.h"
 
 
static bool s_global_init_status = 0;       
 
 

static size_t http_data_writer(void* buffer, size_t size, size_t nmemb, void* content)
{
    long totalSize = size*nmemb;
    st_curl_rec* p_rec = (st_curl_rec*)content;
 
    if((NULL != buffer) && (totalSize < (sizeof(p_rec->rec) - p_rec->len)))
    {
        memcpy((char*)(p_rec->rec + p_rec->len), (char*)buffer, totalSize);
        p_rec->len = p_rec->len + totalSize;
        return totalSize;
    }
    else
    {
        printf("http_data_writer data error(%d) \n", errno);
        return 0;
    }
 
}

CURL* curl_init_resource()
{
    return curl_easy_init();
}
 
int curl_release_resource(CURL* curl)
{
    if(NULL == curl)
    {
        printf("rurl_release_resource curl ptr is null \n");
        return -1;
    }
    curl_easy_cleanup(curl);
    curl = NULL;
 
    return 0;
}
 

#define  XML_FORMAT_STRING        "Content-Type: application/xml;charset=UTF-8"
#define  JSON_FORMAT_STRING       "Content-Type: application/json;charset=UTF-8"
#define  TEMP_FORMAT_MAX_SIZE     (128)

static int curl_set_headers(CURL* curl, const int format,  struct curl_slist** headers)
{
    if(NULL == curl || NULL == headers)
    {
        printf("curl_set_headers curl or headers ptr is null \n");
        return -1;
    }
 
    char temp[TEMP_FORMAT_MAX_SIZE] = {0};
    if(FORMAT_XML == format)
    {
        strncpy(temp, (char*)XML_FORMAT_STRING, sizeof(temp)-1);
    }
    else if(FORMAT_JSON == format)
    {
        strncpy(temp, (char*)JSON_FORMAT_STRING, sizeof(temp)-1);
    }
    
    if(NULL != temp && '\0' != temp[0])
    {
        *headers = curl_slist_append(NULL, (char*)temp);
        if(NULL == headers)
        {
            printf("curl_set_headers format error(%d) \n", errno);
            return -1;
        }
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, *headers);
        return 0;
    }
    
    return -1;
}

static int set_user_pwd(CURL* curl, const st_curl_params* curl_params) {
  #if 0 
    char temp[MAX_TEMP_LEN] = {0};
    if( NULL == curl || NULL == curl_params )
    {
        printf("set_user_pwd curl or curl_params ptr is null \n");
        return -1;
    }
 
    if( curl_params->user[0] && curl_params->pwd[0] )
    {
        snprintf(temp, sizeof(temp)-1, "%s:%s", curl_params->user, curl_params->pwd);
        curl_easy_setopt(curl, CURLOPT_USERPWD, temp);
    }
#endif 
    return 0;
}
 
 
static int message_public_method(CURL* curl, st_curl_params* curl_params)
{
 
 
    if(NULL == curl || NULL == curl_params)
    {
        printf("message_public_method curl or curl_params ptr is null \n");
        return -1;       
    }
 
    if(!(curl_params->ip[0]))
    {
        printf("message_public_method ip ptr is null \n");
        return -1;
    }
    char url[MAX_URL_LEN] = {0};
    snprintf(url, sizeof(url)-1, "http://%s%s", curl_params->ip, curl_params->url_path);
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_PORT, curl_params->port);
 
    int nCode = -1;
    nCode = set_user_pwd(curl, curl_params);
    if(0 != nCode)
    {
        printf("message_public_method call set_user_pwd error(%d) \n", errno);
        return -1;
    }
 
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1);
 
    if(0 >= curl_params->connect_timeout)
    {
        curl_params->connect_timeout = C_CONNECT_DEFAULT_TIMEOUT;
    }
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, curl_params->connect_timeout);
 
    if(0 >= curl_params->timeout)
    {
        curl_params->timeout = C_DEFAULT_TIMEOUT;
    }
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, curl_params->timeout);

	/*if target web server is different than one before, we need to disable reconnection attribution of " the " curl */
    curl_easy_setopt(curl, CURLOPT_FORBID_REUSE, 1);
 
    return 0;
 
}
 
 
static int handle_return_code(CURL* curl, const CURLcode res)
{

	int nCode = 0;
    const char* pRes = NULL;
    pRes = curl_easy_strerror(res);
    printf("%s\n",pRes);
 
    long lResCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &lResCode);
 
    if( CURLE_OK != res || 200 != lResCode)
    {
        if(CURLE_OPERATION_TIMEOUTED == res)
        {
            nCode = 1;  
        }
        else
        {
            nCode = -1; 
        }
        printf("curl send msg error: pRes=%s, lResCode=%ld \n", pRes, lResCode);
    }
	
	return nCode;
}
 
 
static int put_msg(CURL* curl,
                   st_curl_params* curl_params,
                   const char* msg,
                   st_curl_rec* curl_rec)
{
    CURLcode res = CURLE_OK;
    int nCode = -1;
 
    if( NULL == curl || NULL == curl_params || NULL == curl_rec )
    {
        printf("put_msg curl or curl_params or curl_rec is null \n");
        return -1;   
    }
 
    curl_easy_setopt( curl, CURLOPT_CUSTOMREQUEST, "PUT" );
    if(NULL != msg && '\0' != msg[0])
    {
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, msg);
    }
    else
    {
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, "");
    }
 
 
    struct curl_slist *headers = NULL;
    if(FORMAT_XML == curl_params->format || FORMAT_JSON == curl_params->format)
    {
        curl_set_headers(curl, curl_params->format, &headers);
    }
 
    nCode = message_public_method(curl, curl_params);
    if(0 != nCode)
    {
        if(NULL != headers)
        {
            curl_slist_free_all(headers);
            headers = NULL;
        }
 
        printf("put_msg call message_public_method failure \n");
        return -1;
    }
 
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, http_data_writer);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)curl_rec);
    res = curl_easy_perform(curl);
 
    if(NULL != headers)
    {
        curl_slist_free_all(headers);
        headers = NULL;
    }
    
    nCode = handle_return_code(curl, res);
	if(0 > nCode)
	{
		printf("deal response code error \n");
	}
 
    return nCode;
 
}
 

static int delete_msg(CURL* curl,
                      st_curl_params* curl_params,
                      const char* msg,
                      st_curl_rec* curl_rec)
{
    CURLcode res = CURLE_OK;
    int nCode = 0;
 
    if(NULL == curl || NULL == curl_params || NULL == curl_rec)
    {
        printf("delete_msg curl or curl_params or curl_rec ptr is null \n");
        return -1;         
    }
 
    curl_easy_setopt(curl,CURLOPT_CUSTOMREQUEST,"DELETE");
 
    struct curl_slist *headers = NULL;
    if(FORMAT_XML == curl_params->format || FORMAT_JSON == curl_params->format)
    {
         curl_set_headers(curl, curl_params->format, &headers);
    }
 
    nCode = message_public_method(curl, curl_params);
    if(0 != nCode)
    {
        if(NULL != headers)
        {
            curl_slist_free_all(headers);
            headers = NULL;
        }
 
        printf("delete_msg call message_public_method failure \n");
        return -1;
    }
 
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, http_data_writer);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)curl_rec);
    res = curl_easy_perform(curl);
    
    if(NULL != headers)
    {
        curl_slist_free_all(headers);
        headers = NULL;
    }
    
    nCode = handle_return_code(curl, res);
	if(0 > nCode)
	{
		printf("deal response code error \n");
	}
 
    return nCode;
 
}


static int get_msg(CURL* curl,
                   st_curl_params* curl_params,
                   const char* msg,
                   st_curl_rec* curl_rec)
{
    CURLcode res = CURLE_OK;
    int nCode = 0;
 
    if(NULL == curl || NULL == curl_params || NULL == curl_rec)
    {
        printf("get_msg curl or curl_params or msg ptr is null \n");
        return -1;       
    }
 
    curl_easy_setopt(curl, CURLOPT_HTTPGET, 1);
 
    struct curl_slist *headers = NULL;
    if(FORMAT_XML == curl_params->format || FORMAT_JSON == curl_params->format)
    {
        curl_set_headers(curl, curl_params->format, &headers);
    }
 
    nCode = message_public_method(curl, curl_params);
    if(0 != nCode)
    {
        if(NULL != headers)
        {
            curl_slist_free_all(headers);
        }
 
        printf("get_msg call message_public_method failure \n");
        return -1;
    }
 
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, http_data_writer);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)curl_rec);
    res = curl_easy_perform(curl);
 
    if(NULL != headers)
    {
        curl_slist_free_all(headers);
        headers = NULL;
    }
    
    nCode = handle_return_code(curl, res);
	if( 0 > nCode)
	{
		printf("deal response code error \n");
	}
 
    return nCode;
 
}
 
int curl_global_init_resource()
{
 
    if(0 == s_global_init_status)
    {
 
        if(CURLE_OK == curl_global_init(CURL_GLOBAL_ALL))
        {
            s_global_init_status = 1;
            return 0;
        }
        else
        {
            printf("curl_global_init error(%d)\n", errno);
            return -1;
        }
 
    }
 
    return 0;
}
 

int curl_global_cleanup_resource()
{
 
    if(1 == s_global_init_status)
    {
        curl_global_cleanup();
        s_global_init_status = 0;
    }
 
    return 0;
}
 
int curl_init_params(st_curl_params* curl_params,
                     const char* ip,
                     const char* url_path,
                     const int port,
                     const char* user,
                     const char* pwd,
                     const int format)
{
    if(NULL == curl_params || NULL == ip)
    {
        printf("curl_init_params curl_params or ip ptr is null \n");
        return -1;
    }
    memset(curl_params, 0, sizeof(*curl_params));
    strncpy(curl_params->ip, ip, sizeof(curl_params->ip)-1);
    curl_params->port = port;
    curl_params->format = format;
 
    if(NULL != url_path)
    {
        strncpy(curl_params->url_path, url_path, sizeof(curl_params->url_path)-1);
    }
 
    if((NULL != user) && (NULL != pwd))
    {
        strncpy(curl_params->user, user, sizeof(curl_params->user)-1);
        strncpy(curl_params->pwd, pwd, sizeof(curl_params->pwd)-1);
    }
 
    return 0;
 
}
 
int send_msg(CURL* curl,
             st_curl_params* curl_params,
             const char* msg,
             const int method,
             st_curl_rec* curl_rec)
{
    if(NULL == curl || NULL == curl_params || NULL == curl_rec)
    {
        printf("send_msg curl or curl_params or curl_rec ptr is null \n");
        return -1;
    }
 
    int nCode = -1;
    memset(curl_rec, 0, sizeof(st_curl_rec));
    switch(method)
    {
        case METHOD_GET:        
        {
            nCode = get_msg(curl, curl_params, msg, curl_rec);
            return nCode;
        }
        case METHOD_PUT:        
        {
            nCode = put_msg(curl, curl_params, msg, curl_rec);
            return nCode;
        }
        case METHOD_DELETE:    
        {
            nCode = delete_msg(curl, curl_params, msg, curl_rec);
            return nCode;
        }
        default:
        {
            printf("send_msg method error\n");
            return -1;
        }
    }
 
    return -1;
}
 

void set_url_path(st_curl_params* curl_params, char* url_path)
{
    strncpy(curl_params->url_path, url_path, sizeof(curl_params->url_path)-1);
}
 
void set_connect_timeout(st_curl_params* curl_params, int connect_timeout)
{
    curl_params->connect_timeout =  connect_timeout;
}
 

void set_timeout(st_curl_params* curl_params, int timeout)
{
    curl_params->timeout =  timeout;
}
 
#if 0


/*key_url_path:  v1/kv/raid0 ,for instance */
/*IP          :  local IP 127.0.0.1 */
/*port        :   8500 as defaulted */
/*out_msg     :  output message from consul agent*/
int curl_kv_read (const char * key_url_path , const char *IP,  int port, char *out_msg){

	int nCode = -1;
	st_curl_rec curl_rec; 
 
    CURL* curl = NULL; 
	char* user = "";
	char* pwd = "";
	
    int   format = FORMAT_JSON;
    int method = METHOD_GET;
	
	st_curl_params curl_params;
    curl_init_params(&curl_params, ip, key_url_path, port, user, pwd, format);

    curl = curl_init_resource();
	nCode = send_msg(curl, &curl_params, NULL, method, &curl_rec);
	printf("get:\n%s\nsize:%d\n", curl_rec.rec, curl_rec.len);
    curl_release_resource(curl);
	
	if ( out_msg != NULL )
	    memcpy(out_msg,curl_rec.rec ,curl_rec.len+1 );
	return 0 ; 
}

#endif 
