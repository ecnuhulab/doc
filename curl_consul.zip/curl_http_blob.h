#ifndef CURL_HTTP_BLOB_H_
#define CURL_HTTP_BLOB_H_
#if 0 
void b64_decode(char *b64src, char *clrdst);
void b64_encode(char *clrstr, char *b64dst);
#endif 

char* base64Decoder(char encoded[], int len_str); 

#endif

