#ifndef CURL_HTTP_DEF_H_
#define CURL_HTTP_DEF_H_
 
#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <stdbool.h>
 
 
#define MAX_IP_LEN        (32)             
#define MAX_URL_PATH_LEN  (128)           
#define MAX_USER_LEN      (64)           
#define MAX_PWD_LEN       (64)          
 
#define MAX_URL_LEN       (168)        
#define MAX_REC_LEN       (1024*512)     
#define MAX_TEMP_LEN      (128)      .
 
#define METHOD_GET         0         
#define METHOD_POST        1        
#define METHOD_PUT         2       
#define METHOD_DELETE      3      
 
#define FORMAT_DEFAULT     0    
#define FORMAT_XML         1   
#define FORMAT_JSON        2  
 
 
#define C_CONNECT_DEFAULT_TIMEOUT  10  
#define C_DEFAULT_TIMEOUT          600 
 
 
 
 
typedef struct st_curl_params
{
    char ip[MAX_IP_LEN];                   
    char url_path[MAX_URL_PATH_LEN];       
    int  port;                              
    char user[MAX_USER_LEN];                
    char pwd[MAX_PWD_LEN];                  
    int  format;                            
    int  connect_timeout;                   
    int  timeout;                          
}st_curl_params;
 
typedef struct st_curl_rec
{
    char rec[MAX_REC_LEN];                  
    int  len;                               
}st_curl_rec;
 
 int curl_global_init_resource();
 
 int curl_global_cleanup_resource();
 
 CURL* curl_init_resource();

 int curl_release_resource(CURL* curl);

 int curl_init_params(st_curl_params* curl_params,
                            const char* ip,
                            const char* url_path,
                            const int port,
                            const char* user,
                            const char* pwd,
                            const int format);
 
 void set_url_path(st_curl_params* curl_params, char* url_path);
 
 void set_connect_timeout(st_curl_params* curl_params, int connect_timeout);
 
 void set_timeout(st_curl_params* curl_params, int timeout);
 
 int send_msg(CURL* curl,
                    st_curl_params* curl_params,
                    const char* msg,
                    const int method,
                    st_curl_rec* curl_rec);
 
#endif

