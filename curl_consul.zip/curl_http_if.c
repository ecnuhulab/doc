#include <string.h>
#include <stdlib.h>
#include "curl_http_def.h"
#include "curl_http_blob.h"

static void kv_curl_parse_Value(const char *src , char *out){
   #if 0 
   char *tmp= NULL ; 
   char val_visible[256]={0};
   char p=val_visible; 
   tmp= strstr(src, "Value"); 
   tmp+=8;
   while ( *tmp != '\"' && *p != '\0'  )
       {  *p=*tmp; p++; tmp++; }

  b64_decode(val_visible, out );   
#endif 
    
}

char *  kv_curl_get_method( const char * ip , int port ,const char *url_path )
{
    char *re =NULL ; 
    int nCode = -1;
    char* user = "";
    char* pwd = "";
    int   format = FORMAT_XML;
    st_curl_params curl_params;
    curl_init_params(&curl_params, ip, url_path, port, user, pwd, format);
    st_curl_rec curl_rec; 
    CURL* curl = NULL; 
    curl = curl_init_resource();
    nCode = send_msg(curl, &curl_params, NULL, METHOD_GET, &curl_rec);
//    printf ("get:\n%s\nsize:%d\n", curl_rec.rec, curl_rec.len);
    curl_release_resource(curl);
    
    re=(char*)malloc(curl_rec.len+1);
    memcpy (re, curl_rec.rec, curl_rec.len+1 );
 
    return re ;
}
 
char * kv_curl_put_method( const char *ip , int port , const char *url_path , const char *msg)
{	
    char *re =NULL ;
    int nCode = -1;
    char* user = "";
    char* pwd = "";
    int   format = FORMAT_JSON;
    st_curl_params curl_params;
    curl_init_params(&curl_params, ip, url_path, port, user, pwd, format);
    st_curl_rec curl_rec; 
	
    CURL* curl = NULL; 
    curl = curl_init_resource();
    nCode = send_msg(curl, &curl_params, msg, METHOD_PUT, &curl_rec);
  //  printf("post:\n%s\nsize:%d\n", curl_rec.rec, curl_rec.len);
    curl_release_resource(curl);

    
    re=(char*)malloc(curl_rec.len+1);
    memcpy (re, curl_rec.rec, curl_rec.len+1 );

    return re; 
	
}

char * event_curl_put_method( const char *ip , const int port , const char *url_path , const char *payload)
{
    char *re =NULL ;
    int nCode = -1;
    char* user = "";
    char* pwd = "";
    int   format = FORMAT_JSON;
    st_curl_params curl_params;
    curl_init_params(&curl_params, ip, url_path, port, user, pwd, format);
    st_curl_rec curl_rec;

    CURL* curl = NULL;
    curl = curl_init_resource();
    nCode = send_msg(curl, &curl_params, payload, METHOD_PUT, &curl_rec);
  //  printf("post:\n%s\nsize:%d\n", curl_rec.rec, curl_rec.len);
    curl_release_resource(curl);


    re=(char*)malloc(curl_rec.len+1);
    memcpy (re, curl_rec.rec, curl_rec.len+1 );

    return re;

}

char *event_curl_get_method( const char * ip , int port ,const char *url_path )
{
    char *re =NULL ;
    int nCode = -1;
    char* user = "";
    char* pwd = "";
    int   format = FORMAT_XML;
    st_curl_params curl_params;
    curl_init_params(&curl_params, ip, url_path, port, user, pwd, format);
    st_curl_rec curl_rec;
    CURL* curl = NULL;
    curl = curl_init_resource();
    nCode = send_msg(curl, &curl_params, NULL, METHOD_GET, &curl_rec);
//    printf ("get:\n%s\nsize:%d\n", curl_rec.rec, curl_rec.len);
    curl_release_resource(curl);

    re=(char*)malloc(curl_rec.len+1);
    memcpy (re, curl_rec.rec, curl_rec.len+1 );

    return re ;
}

char *event_curl_consul_get_raw (void ) {
    char  event_path [64] = {0};
    strcpy( event_path,  "/v1/event/") ;
    return event_curl_get_method("127.0.0.1", 8500,strcat( event_path, "list" ) ;
}
#include "curl_goes_parse.h"


typedef struct ep_struct {
  char *event_name ;
  int event_len;
  char * payload;
  int  payload_len;
}EP ;

#define EVENT_BUF_SIZE (1024)  /*this value is from consul event list queue size */
EP *EP_head = NULL ;

int curl_consul_event_recv_init ( void );

int curl_consul_event_recv_init ( void )
{
    EP_head =(EP*)malloc (sizeof (EP) * EVENT_BUF_SIZE);
    if ( EP_head == NULL )
          return -1 ;
    memset (EP_head, 0 , sizeof (EP) * EVENT_BUF_SIZE);
    for ( int i=0; i< EVENT_BUF_SIZE ; i++ ) {
        EP_head[i].event_name = NULL ;
        EP_head[i].payload = NULL ;

    }
    return 0 ;
}

int curl_consul_event_recv_free ( void )
{
    for ( int i=0; i< EVENT_BUF_SIZE ; i++ ) {
        if ( EP_head[i].event_name != NULL )
            free ( EP_head[i].event_name) ;

        if (  EP_head[i].payload != NULL)
            free (EP_head[i].payload) ;

    }
    free( EP_head ) ;
    EP_head = NULL ;

}


int parse_function ( char * buffer ,  EP *list , int count, int *start, int *sz )
{
    static int EP_index=0;
    static int LP_time_index = 0 ;
    cGOES *root = NULL ;
    int array_size = 0 ;
    int i = 0;
    cGOES *item;
    int j =0 ;
    *start = EP_index ;
    root = cGOES_Parse(buffer);

    if(!root) {
        printf("get root faild !\n");
        return -1;
    }

    array_size = cGOES_GetArraySize(root);

    for( i=0; i < array_size; i++) {
        item = cGOES_GetArrayItem(root, i);

        cGOES *lptime = cGOES_GetObjectItem(item, "LTime");
        if(!lptime) {
            printf("no lptime !\n");
            return -1;
        }
        if ( lptime->valueint <=  LP_time_index )   {
        /* the above is the older event message . Ignore them */
            continue ;
        }

        int cur_ep_index = ( EP_index + j ) % count ;

        cGOES *name = cGOES_GetObjectItem(item, "Name");
        if(!name) {
            printf("No name !\n");
            return -1;
        }

        if (  list[cur_ep_index]->event_name )
            free (list[cur_ep_index]->event_name);

        list[cur_ep_index]->event_len=strlen (name->valuestring) +1;
        list[cur_ep_index]->event_name = malloc (list[cur_ep_index]->event_len);
        strcpy(list[cur_ep_index]->event_name,name->valuestring);

        cGOES *content = cGOES_GetObjectItem(item, "Payload");
        if( !content ) {
            printf("No payload !\n");
            return -1;
        }

        if (  list[cur_ep_index]->payload )
            free (list[cur_ep_index]->payload);

        list[cur_ep_index]->payload_len=strlen (content->valuestring) +1;
        list[cur_ep_index]->payload = malloc (list[cur_ep_index]->payload_len);
        strcpy(list[cur_ep_index]->payload,content->valuestring);

        EP_index = cur_ep_index ;
        LP_time_index = lptime->valueint ;

   }

   *sz = EP_index - (*start) ;
   if(root) {
       cGOES_Delete(root);
   }
   return 0 ;


}  /*end of parer function */


int curl_consul_recv_event ( EP *list , int *start , int *sz) {

   char *rev_buf = event_curl_consul_get_raw ();

   return parse_function ( rev_buf, list, *start, *sz) ; 
 
}



