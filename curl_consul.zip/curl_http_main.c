#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "curl_http_def.h"
#include "curl_http_blob.h"
extern char * kv_curl_put_method( const char *ip , int port , const char *url_path , const char *msg);
extern char *  kv_curl_get_method( const char * ip , int port ,const char *url_path );
extern char * event_curl_put_method( const char *ip , const int port , const char *url_path , const char *payload);
extern char *  event_curl_get_method( const char * ip , int port ,const char *url_path );
int parse (char *resp , )
/*Usage :  curl_http  kv|event get|put name [ payload ] */
int main(int argc ,char *argv[] )
{

  
   if (argc  < 4   ) 
     return 0 ;
   char *re = NULL ;

   if ( strncmp (argv[1] ,"kv", 2 )==0 ) {
       char  kv_path [32] = {0};
       strcpy( kv_path,  "/v1/kv/") ;
       if ( strncmp (argv[2] ,"get", 3 )==0 ) {
   
             re =kv_curl_get_method("127.0.0.1", 8500,strcat( kv_path, argv[3]) );
   
       } else if (strncmp (argv[2] ,"put", 3 )==0) {
   
             re = kv_curl_put_method ("127.0.0.1", 8500,strcat( kv_path, argv[3]),argv[4]);

       } else {
    
           return 0 ;
       }

   }
   
   else if (strncmp (argv[1] ,"eve", 3 )==0 )  {

       char  event_path [64] = {0};
       strcpy( event_path,  "/v1/event/") ;
       if ( strncmp (argv[2] ,"get", 3 )==0 ) {
             /*argv[3]  == "list" here */
             re =event_curl_get_method("127.0.0.1", 8500,strcat( event_path, argv[3]) ) ; 

       } else if (strncmp (argv[2] ,"put", 3 )==0) {
             strcpy( event_path,  "fire/") ;

             re = event_curl_put_method ("127.0.0.1", 8500,strcat( event_path, argv[3]),argv[4]);

       } else {

           return 0 ;
       }


   } else {
 
     return 0 ;
   }
  
   #if 0
   char *re = NULL ; 
   if( argc ==4 )
   {
       re=kv_curl_get_method(argv[1], atoi(argv[2]),argv[3]); 
   } else if ( argc ==5 ) {
       re=kv_curl_put_method (argv[1], atoi(argv[2]),argv[3],argv[4]);
   }
   else {
       printf ("input wrong argument ");
   }
   if ( argc ==4 ) {
   char *tmp =strstr(re,"Value"); 
   tmp=tmp+9; 
   char *last = strstr(tmp,"\"");
   int len = last -tmp ;
#endif  
   #if 0
   char blob_data [1024] = {0} ; 
   //memset (blob_data, 0 , len+1);
   strncpy (blob_data , tmp , len);
   blob_data[len+1]='\0';
   printf (" blob value: %s \n ", blob_data);
   char out[1024]= {0}; 
   b64_decode ( "MQ==" , out );
   printf ( "value : %s\n", ); 
//   free (blob_data);
  printf ("%s \n",base64Decoder(tmp,len)); 
   } 
#endif 
   if (re != NULL ){  
       printf ( "%s\n ", re);
       parse (re);
       free (re);
   }

  return 0 ;
   
}
