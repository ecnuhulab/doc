
File overview 
=============

curl_goes_parse.c  : curl parser is used to  parse http responses buffer from Consul after user sent out CONSUL http API command 
packaged with curl_http_if.c 
curl_http_if.c    :  this file includes  curl user interfaces with consul http api

curl_http_api.c   :  it mainly applies curl lib API to send/receive http request/response 

curl_http_blob.c  :  blob data paser , a translation between blob data and readable char string 

curl_http_main.c / wg.c :  The two are the verification against the above functions 

Compile Command 
===============

curl_http :
    gcc -o curl_http curl_http_main.c curl_http_blob.c curl_http_api.c  curl_http_if.c  -lcurl

wg : 
   gcc -o wg wg.c curl_goes_parse.c 

Run and Log 
===========
  wg run : 
  
tenderbulk@ubuntu:~/curl_consul$ ./wg
name type is 16
name is xiao hong
age type is 8
age is 10
name type is 16
name is xiao wang
age type is 8
age is 13
name type is 16
name is xiao fang
age type is 8
age is 30

curl_http run : 
   Note: please first get the consul started up by run $GOPATH/bin/consul agent -dev & 


  tenderbulk@ubuntu:~/curl_consul$ ./curl_http event get list
    2019/07/26 16:22:59 [DEBUG] http: Request GET /v1/event/list (123.499µs) from=127.0.0.1:42840
No error
[
    {
        "ID": "fa4cecf3-10ab-00a9-ed0c-a3ef0b036078",
        "Name": "TOYOU_rdevent99_127.0.0.1:8300",
        "Payload": "XzExMTExMTExMTExMTExMTExMTFf",
        "NodeFilter": "",
        "ServiceFilter": "",
        "TagFilter": "",
        "Version": 1,
        "LTime": 2
    },
    {
        "ID": "4e62ce48-6793-369c-851c-ddd7af506427",
        "Name": "TOYOU_rdevent6_127.0.0.1:8300",
        "Payload": "XzExMTExMTExMTExMTExMTExMTFf",
        "NodeFilter": "",
        "ServiceFilter": "",
        "TagFilter": "",
        "Version": 1,
        "LTime": 3
    }
]


